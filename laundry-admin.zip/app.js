const { useState, useEffect, useRef } = React;

// Debug logging helper
function createDebugLogger() {
  const logs = [];
  return {
    add: (message, type = 'info') => {
      const timestamp = new Date().toLocaleTimeString('ko-KR');
      const log = { timestamp, message, type };
      logs.push(log);
      console.log(`[${timestamp}] ${message}`);
      return log;
    },
    get: () => [...logs],
    clear: () => { logs.length = 0; }
  };
}

// In-memory storage (NO localStorage - sandbox environment)
const memoryStorage = {
  user: null,
  token: null,
  subscriptions: [],
  surveyAnswers: {},
  serverUrl: 'http://localhost:8000',
  logs: []
};

// Note: No initial data - everything loaded from API

const initialWashingMachines_UNUSED = [
  {
    id: 'machine_1_1',
    room_id: 'room_1',
    machine_number: 1,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 15 * 60000).toISOString(),
    current_cycle: 'wash',
    battery: 85,
    vibration_magnitude: 120,
    user_input_time: 20,
    stat_time: 18
  },
  {
    id: 'machine_1_2',
    room_id: 'room_1',
    machine_number: 2,
    status: 'available',
    battery: 92,
    vibration_magnitude: 0
  },
  {
    id: 'machine_1_3',
    room_id: 'room_1',
    machine_number: 3,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 20 * 60000).toISOString(),
    current_cycle: 'spin',
    battery: 78,
    vibration_magnitude: 150,
    user_input_time: 25,
    stat_time: 22
  },
  {
    id: 'machine_1_4',
    room_id: 'room_1',
    machine_number: 4,
    status: 'available',
    battery: 95,
    vibration_magnitude: 0
  },
  {
    id: 'machine_1_5',
    room_id: 'room_1',
    machine_number: 5,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 10 * 60000).toISOString(),
    current_cycle: 'wash',
    battery: 70,
    vibration_magnitude: 110,
    user_input_time: 15,
    stat_time: 12
  },
  {
    id: 'machine_1_6',
    room_id: 'room_1',
    machine_number: 6,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 8 * 60000).toISOString(),
    current_cycle: 'rinse',
    battery: 88,
    vibration_magnitude: 95,
    user_input_time: 10,
    stat_time: 9
  },
  {
    id: 'machine_1_7',
    room_id: 'room_1',
    machine_number: 7,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 12 * 60000).toISOString(),
    current_cycle: 'spin',
    battery: 82,
    vibration_magnitude: 140,
    user_input_time: 13,
    stat_time: 11
  },
  {
    id: 'machine_1_8',
    room_id: 'room_1',
    machine_number: 8,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 18 * 60000).toISOString(),
    current_cycle: 'wash',
    battery: 76,
    vibration_magnitude: 125,
    user_input_time: 22,
    stat_time: 19
  },
  {
    id: 'machine_2_1',
    room_id: 'room_2',
    machine_number: 1,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 35 * 60000).toISOString(),
    current_cycle: 'spin',
    battery: 78,
    vibration_magnitude: 180,
    user_input_time: 40,
    stat_time: 35
  },
  {
    id: 'machine_2_2',
    room_id: 'room_2',
    machine_number: 2,
    status: 'available',
    battery: 88,
    vibration_magnitude: 0
  },
  {
    id: 'machine_2_3',
    room_id: 'room_2',
    machine_number: 3,
    status: 'available',
    battery: 91,
    vibration_magnitude: 0
  },
  {
    id: 'machine_2_4',
    room_id: 'room_2',
    machine_number: 4,
    status: 'available',
    battery: 94,
    vibration_magnitude: 0
  },
  {
    id: 'machine_2_5',
    room_id: 'room_2',
    machine_number: 5,
    status: 'available',
    battery: 89,
    vibration_magnitude: 0
  },
  {
    id: 'machine_2_6',
    room_id: 'room_2',
    machine_number: 6,
    status: 'broken',
    battery: 45,
    vibration_magnitude: 0
  },
  {
    id: 'machine_3_1',
    room_id: 'room_3',
    machine_number: 1,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 25 * 60000).toISOString(),
    current_cycle: 'wash',
    battery: 80,
    vibration_magnitude: 115,
    user_input_time: 30,
    stat_time: 26
  },
  {
    id: 'machine_3_2',
    room_id: 'room_3',
    machine_number: 2,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 30 * 60000).toISOString(),
    current_cycle: 'rinse',
    battery: 85,
    vibration_magnitude: 100,
    user_input_time: 35,
    stat_time: 32
  },
  {
    id: 'machine_3_3',
    room_id: 'room_3',
    machine_number: 3,
    status: 'available',
    battery: 93,
    vibration_magnitude: 0
  },
  {
    id: 'machine_3_4',
    room_id: 'room_3',
    machine_number: 4,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 22 * 60000).toISOString(),
    current_cycle: 'spin',
    battery: 75,
    vibration_magnitude: 160,
    user_input_time: 28,
    stat_time: 24
  },
  {
    id: 'machine_3_5',
    room_id: 'room_3',
    machine_number: 5,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 14 * 60000).toISOString(),
    current_cycle: 'wash',
    battery: 82,
    vibration_magnitude: 118,
    user_input_time: 17,
    stat_time: 15
  },
  {
    id: 'machine_3_6',
    room_id: 'room_3',
    machine_number: 6,
    status: 'available',
    battery: 90,
    vibration_magnitude: 0
  },
  {
    id: 'machine_3_7',
    room_id: 'room_3',
    machine_number: 7,
    status: 'running',
    estimated_end_time: new Date(Date.now() + 16 * 60000).toISOString(),
    current_cycle: 'rinse',
    battery: 79,
    vibration_magnitude: 105,
    user_input_time: 19,
    stat_time: 17
  },
  {
    id: 'machine_3_8',
    room_id: 'room_3',
    machine_number: 8,
    status: 'available',
    battery: 96,
    vibration_magnitude: 0
  }
];

const surveyQuestions = [
  {
    id: 'q1',
    question: '세탁 서비스의 만족도를 평가해주세요',
    type: 'rating',
    options: [1, 2, 3, 4, 5]
  },
  {
    id: 'q2',
    question: '가장 불편한 점은 무엇인가요?',
    type: 'multiple_choice',
    options: ['대기 시간', '세탁기 상태 파악', '알림 기능', '기타']
  },
  {
    id: 'q3',
    question: '추가로 원하는 기능이 있나요?',
    type: 'text',
    options: []
  }
];

// API Helper Functions
function getServerUrl() {
  return memoryStorage.serverUrl;
}

async function apiCall(endpoint, options = {}) {
  const url = `${getServerUrl()}${endpoint}`;
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('API call failed:', error);
    throw error;
  }
}

// Login Component
function LoginPage({ onLogin }) {
  const [isSignup, setIsSignup] = useState(false);
  const [snum, setSnum] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [serverUrl, setServerUrl] = useState(memoryStorage.serverUrl);
  const [debugLog, setDebugLog] = useState([]);
  const [testing, setTesting] = useState(false);

  const addDebugLog = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString('ko-KR');
    const log = { timestamp, message, type };
    setDebugLog(prev => [...prev, log]);
    console.log(`[${timestamp}] ${message}`);
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setError('');
    setDebugLog([]);
    
    try {
      addDebugLog('서버 연결 확인 중...', 'info');
      const response = await fetch(`${serverUrl}/health`);
      
      if (response.ok) {
        addDebugLog('✓ 서버 연결 성공', 'success');
      } else {
        addDebugLog(`✗ 서버 응답 오류: ${response.status}`, 'error');
      }
    } catch (err) {
      addDebugLog('✗ 서버에 연결할 수 없습니다: ' + err.message, 'error');
      setError('서버에 연결할 수 없습니다');
    } finally {
      setTesting(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setDebugLog([]);

    try {
      if (isSignup) {
        addDebugLog('회원가입 시도 중...', 'info');
        // Register
        await apiCall('/register', {
          method: 'POST',
          body: JSON.stringify({
            user_username: username,
            user_password: password,
            user_role: false,
            user_snum: parseInt(snum)
          })
        });
        addDebugLog('✓ 회원가입 완료', 'success');
        alert('회원가입 완료! 로그인해주세요.');
        setIsSignup(false);
      } else {
        // Step 1: Check server
        addDebugLog('1단계: 서버 연결 확인 중...', 'info');
        const healthResponse = await fetch(`${serverUrl}/health`);
        if (!healthResponse.ok) {
          throw new Error('서버에 연결할 수 없습니다');
        }
        addDebugLog('✓ 서버 연결 성공', 'success');
        
        // Step 2: Login
        addDebugLog('2단계: 로그인 시도 중...', 'info');
        const loginResponse = await fetch(`${serverUrl}/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            user_snum: parseInt(snum),
            user_password: password,
            fcm_token: 'web_client'
          })
        });
        
        if (!loginResponse.ok) {
          const errorData = await loginResponse.json().catch(() => ({}));
          throw new Error(errorData.detail || '로그인 실패');
        }
        
        const loginData = await loginResponse.json();
        const token = loginData.access_token;
        
        if (!token) {
          throw new Error('토큰을 받지 못했습니다');
        }
        
        memoryStorage.token = token;
        memoryStorage.user = { snum, username: username || snum };
        memoryStorage.serverUrl = serverUrl;
        addDebugLog('✓ 로그인 성공, 토큰 저장됨', 'success');
        
        // Step 3: Navigate
        addDebugLog('3단계: 세탁실 목록 페이지로 이동...', 'info');
        setTimeout(() => {
          onLogin({ snum, username: username || snum, token: token });
        }, 500);
      }
    } catch (err) {
      const errorMsg = `로그인 실패: ${err.message}`;
      setError(errorMsg);
      addDebugLog('✗ ' + errorMsg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleServerUrlChange = () => {
    memoryStorage.serverUrl = serverUrl;
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>{isSignup ? '회원가입' : '로그인'}</h2>
        <div className="form-group">
          <label>서버 URL</label>
          <input
            type="text"
            value={serverUrl}
            onChange={(e) => setServerUrl(e.target.value)}
            onBlur={handleServerUrlChange}
            placeholder="http://localhost:8000"
          />
        </div>
        {debugLog.length > 0 && (
          <div style={{marginBottom: '1rem', padding: '1rem', backgroundColor: '#1f2937', color: '#fff', borderRadius: '8px', maxHeight: '300px', overflowY: 'auto', fontFamily: 'monospace', fontSize: '0.8rem'}}>
            <div style={{fontSize: '0.95rem', fontWeight: 'bold', marginBottom: '0.75rem', color: '#10b981'}}>🔍 실시간 로그</div>
            {debugLog.map((log, i) => (
              <div key={i} style={{
                marginBottom: '0.4rem',
                padding: '0.25rem',
                color: log.type === 'error' ? '#f87171' : log.type === 'success' ? '#34d399' : log.type === 'warn' ? '#fbbf24' : '#d1d5db'
              }}>
                <span style={{opacity: 0.7}}>[{log.timestamp}]</span> {log.message}
              </div>
            ))}
          </div>
        )}
        {error && <div style={{color: '#fff', marginBottom: '1rem', fontSize: '0.95rem', padding: '1rem', backgroundColor: '#dc2626', borderRadius: '8px', fontWeight: 'bold'}}>⚠️ {error}</div>}
        <form onSubmit={handleSubmit}>
          {isSignup && (
            <div className="form-group">
              <label>이름</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                placeholder="홍길동"
              />
            </div>
          )}
          <div className="form-group">
            <label>학번</label>
            <input
              type="text"
              value={snum}
              onChange={(e) => setSnum(e.target.value)}
              required
              placeholder="123456"
            />
          </div>
          <div className="form-group">
            <label>비밀번호</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
            />
          </div>
          {!isSignup && (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={handleTestConnection}
              disabled={loading || testing}
              style={{marginBottom: '0.5rem'}}
            >
              {testing ? '테스트 중...' : '🔌 서버 연결 테스트'}
            </button>
          )}
          <button type="submit" className="btn btn-primary" disabled={loading || testing}>
            {loading ? '처리 중...' : (isSignup ? '가입하기' : '로그인')}
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => setIsSignup(!isSignup)}
            disabled={loading || testing}
          >
            {isSignup ? '로그인으로 돌아가기' : '회원가입'}
          </button>
        </form>
      </div>
    </div>
  );
}

// Navigation Component
function Navbar({ currentPage, onNavigate, onLogout, wsConnected }) {
  return (
    <nav className="navbar">
      <div className="navbar-content">
        <div className="navbar-brand">🧺 세탁실 관리</div>
        <ul className="navbar-menu">
          <li>
            <a
              href="#"
              className={currentPage === 'rooms' ? 'active' : ''}
              onClick={(e) => { e.preventDefault(); onNavigate('rooms'); }}
            >
              🏠 전체 세탁실
            </a>
          </li>
          <li>
            <a
              href="#"
              className={currentPage === 'subscriptions' ? 'active' : ''}
              onClick={(e) => { e.preventDefault(); onNavigate('subscriptions'); }}
            >
              ⭐ 내 구독
            </a>
          </li>
          <li>
            <button onClick={onLogout}>🚪 로그아웃</button>
          </li>
          {wsConnected && (
            <li style={{color: 'var(--color-success)', display: 'flex', alignItems: 'center', gap: '0.25rem'}}>
              🟢 실시간
            </li>
          )}
        </ul>
      </div>
    </nav>
  );
}

// Congestion Bar Component
function CongestionBar({ congestion }) {
  const getColor = () => {
    if (congestion < 40) return 'progress-low';
    if (congestion < 70) return 'progress-medium';
    return 'progress-high';
  };

  return (
    <div className="congestion-bar">
      <div className="congestion-label">
        <span>혼잡도</span>
        <span>{congestion}%</span>
      </div>
      <div className="progress-bar">
        <div
          className={`progress-fill ${getColor()}`}
          style={{ width: `${congestion}%` }}
        ></div>
      </div>
    </div>
  );
}

// All Laundry Rooms List Component (전체 세탁실)
function AllRoomsList({ rooms, onSelectRoom, mySubscriptions, onToggleSubscribe, errorMessage, onRefresh, loading, debugLog, showDebug, onToggleDebug }) {
  const isSubscribed = (roomId) => {
    return mySubscriptions.includes(roomId);
  };

  const renderDebugPanel = () => {
    if (debugLog.length === 0) return null;
    
    return (
      <div style={{
        marginBottom: '1.5rem',
        padding: '1rem',
        backgroundColor: '#1f2937',
        color: '#fff',
        border: '2px solid #10b981',
        borderRadius: '8px',
        maxHeight: '400px',
        overflowY: 'auto'
      }}>
        <div style={{marginBottom: '0.75rem', paddingBottom: '0.5rem', borderBottom: '1px solid #374151'}}>
          <h3 style={{fontSize: '1.1rem', margin: 0, color: '#10b981', fontWeight: 'bold'}}>🔍 실시간 로그 (모든 API 호출 표시)</h3>
        </div>
        {debugLog.length === 0 && (
          <div style={{color: '#9ca3af', fontStyle: 'italic'}}>로그가 없습니다. '새로고침' 버튼을 누르세요.</div>
        )}
        {debugLog.map((log, i) => (
          <div key={i} style={{
            fontSize: '0.85rem',
            marginBottom: '0.4rem',
            padding: '0.35rem',
            color: log.type === 'error' ? '#f87171' : 
                   log.type === 'success' ? '#34d399' : 
                   log.type === 'warn' ? '#fbbf24' :
                   '#d1d5db',
            fontFamily: 'monospace',
            backgroundColor: log.type === 'error' ? 'rgba(248, 113, 113, 0.1)' : 
                           log.type === 'success' ? 'rgba(52, 211, 153, 0.1)' : 'transparent',
            borderRadius: '4px'
          }}>
            <span style={{opacity: 0.7, fontSize: '0.75rem'}}>[{log.timestamp}]</span> {log.message}
          </div>
        ))}
      </div>
    );
  };



  if (loading && rooms.length === 0 && !errorMessage) {
    return (
      <div className="container">
        <div className="page-header">
          <h1>전체 세탁실</h1>
          <p>모든 세탁실 목록</p>
        </div>
        {renderDebugPanel()}
        <div className="loading">세탁실 목록을 불러오는 중...</div>
      </div>
    );
  }

  if (errorMessage && rooms.length === 0) {
    return (
      <div className="container">
        <div className="page-header">
          <h1>전체 세탁실</h1>
          <p>모든 세탁실 목록</p>
        </div>
        {renderDebugPanel()}
        <div className="empty-state">
          <p style={{marginBottom: '1rem', color: 'var(--color-danger)', fontSize: '1.1rem', fontWeight: 'bold'}}>⚠️ {errorMessage}</p>
          <div style={{textAlign: 'left', maxWidth: '600px', margin: '0 auto 1.5rem', fontSize: '0.95rem', lineHeight: '1.6'}}>
            <p style={{fontWeight: 'bold', marginBottom: '0.5rem'}}>해결 방법:</p>
            <ol style={{paddingLeft: '1.5rem'}}>
              <li>먼저 세탁실을 구독해주세요 (서버에서 구독 기능 사용)</li>
              <li>또는 서버에 <code>/rooms</code> API를 추가하세요</li>
              <li>로그를 확인하여 정확한 원인을 파악하세요</li>
            </ol>
          </div>
          <button className="btn btn-primary" onClick={onRefresh}>
            🔄 다시 시도
          </button>
        </div>
      </div>
    );
  }

  if (!loading && rooms.length === 0 && !errorMessage) {
    return (
      <div className="container">
        <div className="page-header">
          <h1>전체 세탁실</h1>
          <p>모든 세탁실 목록</p>
        </div>
        {renderDebugPanel()}
        <div className="empty-state">
          <div style={{fontSize: '3rem', marginBottom: '1rem'}}>🧺</div>
          <h2 style={{marginBottom: '1rem'}}>구독한 세탁실이 없습니다</h2>
          <div style={{textAlign: 'left', maxWidth: '600px', margin: '0 auto 1.5rem', fontSize: '0.95rem', lineHeight: '1.6'}}>
            <p style={{fontWeight: 'bold', marginBottom: '0.5rem'}}>이 앱은 /load API만 사용합니다:</p>
            <ul style={{paddingLeft: '1.5rem'}}>
              <li>/load API는 구독한 세탁실만 반환합니다</li>
              <li>먼저 서버에서 세탁실을 구독해주세요</li>
              <li>모든 세탁실을 보려면 서버에 /rooms API를 추가하세요</li>
            </ul>
          </div>
          <button className="btn btn-primary" onClick={onRefresh} style={{marginTop: '0.5rem'}}>
            🔄 다시 시도
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="page-header">
        <h1>전체 세탁실 ({rooms.length}개)</h1>
        <p>모든 세탁실 목록</p>
      </div>
      <div style={{marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem'}}>
        <div style={{fontSize: '0.875rem', color: 'var(--color-text-secondary)'}}>
          📊 /load API를 사용하여 구독한 세탁실만 표시됩니다
        </div>
        <button className="btn btn-small btn-secondary" onClick={onRefresh} disabled={loading}>
          {loading ? '⏳ 로딩 중...' : '🔄 새로고침'}
        </button>
      </div>
      {renderDebugPanel()}
      <div className="cards-grid">
        {rooms.map(room => (
          <div key={room.id} className="card">
            <div className="card-header" style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem'}}>
              <h3 style={{cursor: 'pointer', flex: 1, margin: 0}} onClick={() => onSelectRoom(room.id)}>{room.name}</h3>
              <button
                className={`btn btn-small ${isSubscribed(room.id) ? 'btn-warning' : 'btn-success'}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleSubscribe(room.id);
                }}
                style={{marginLeft: '0.5rem'}}
              >
                {isSubscribed(room.id) ? '⭐ 구독중' : '☆ 구독'}
              </button>
            </div>
            <CongestionBar congestion={room.congestion} />
            <div className="card-info">
              <span>사용가능: {room.available_machines}</span>
              <span>/</span>
              <span>전체: {room.total_machines}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// My Subscriptions Page Component (내 구독)
function MySubscriptionsPage({ allRooms, mySubscriptions, onSelectRoom, onToggleSubscribe, onNavigateToAllRooms }) {
  const subscribedRooms = allRooms.filter(room => mySubscriptions.includes(room.id));

  return (
    <div className="container">
      <div className="page-header">
        <h1>내가 구독한 세탁실 ({subscribedRooms.length}개)</h1>
        <p>구독한 세탁실만 표시됩니다</p>
      </div>
      {subscribedRooms.length === 0 ? (
        <div className="empty-state">
          <p style={{marginBottom: '1rem'}}>구독한 세탁실이 없습니다</p>
          <button className="btn btn-primary" onClick={onNavigateToAllRooms}>
            세탁실 구독하러 가기
          </button>
        </div>
      ) : (
        <div className="cards-grid">
          {subscribedRooms.map(room => (
            <div key={room.id} className="card" style={{backgroundColor: 'rgba(251, 191, 36, 0.05)'}}>
              <div className="card-header" style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem'}}>
                <h3 style={{cursor: 'pointer', flex: 1, margin: 0}} onClick={() => onSelectRoom(room.id)}>{room.name}</h3>
                <button
                  className="btn btn-small btn-danger"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSubscribe(room.id);
                  }}
                  style={{marginLeft: '0.5rem'}}
                >
                  ❌ 구독취소
                </button>
              </div>
              <CongestionBar congestion={room.congestion} />
              <div className="card-info">
                <span>사용가능: {room.available_machines}</span>
                <span>/</span>
                <span>전체: {room.total_machines}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Timer Display Component
function TimerDisplay({ machine }) {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (machine.status !== 'running') return;

    const calculateTimeLeft = () => {
      const end = new Date(machine.estimated_end_time).getTime();
      const now = Date.now();
      const diff = Math.max(0, Math.floor((end - now) / 1000));
      return diff;
    };

    setTimeLeft(calculateTimeLeft());

    const interval = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(interval);
  }, [machine.estimated_end_time, machine.status]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Adaptive Hybrid Timer Calculation
  const sensorTime = machine.vibration_magnitude > 0 
    ? Math.floor(machine.vibration_magnitude / 10) 
    : 0;
  const userTime = machine.user_input_time || 0;
  const statTime = machine.stat_time || 0;
  
  // Weighted average: 40% sensor, 30% user, 30% statistics
  const hybridTime = Math.floor((sensorTime * 0.4 + userTime * 0.3 + statTime * 0.3));

  if (machine.status !== 'running') return null;

  return (
    <>
      <div className="timer-display">
        {formatTime(timeLeft)}
      </div>
      <div className="timer-details">
        <div>
          <span>센서 기반</span>
          <span>{sensorTime}분</span>
        </div>
        <div>
          <span>사용자 입력</span>
          <span>{userTime}분</span>
        </div>
        <div>
          <span>통계 기반</span>
          <span>{statTime}분</span>
        </div>
        <div>
          <span>적응형 예측</span>
          <span>{hybridTime}분</span>
        </div>
      </div>
    </>
  );
}

// Machine Card Component
function MachineCard({ machine, onSubscribe, onUnsubscribe, isSubscribed }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(machine.machine_name || `세탁기 #${machine.machine_number}`);
  const [saving, setSaving] = useState(false);

  const handleSaveName = async () => {
    if (!editedName.trim() || editedName === machine.machine_name) {
      setIsEditing(false);
      return;
    }

    setSaving(true);
    try {
      const response = await fetch(`${getServerUrl()}/update_machine_name`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          access_token: memoryStorage.token,
          machine_id: machine.id,
          new_name: editedName
        })
      });

      if (response.ok) {
        machine.machine_name = editedName;
        alert('이름이 변경되었습니다');
      } else {
        alert('이름 변경에 실패했습니다');
        setEditedName(machine.machine_name);
      }
    } catch (error) {
      console.error('Failed to update machine name:', error);
      alert('이름 변경 중 오류가 발생했습니다');
      setEditedName(machine.machine_name);
    } finally {
      setSaving(false);
      setIsEditing(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSaveName();
    } else if (e.key === 'Escape') {
      setEditedName(machine.machine_name);
      setIsEditing(false);
    }
  };

  const getStatusText = (status) => {
    const statusMap = {
      'running': '사용 중',
      'available': '사용 가능',
      'broken': '고장',
      'WASHING': '세탁 중',
      'SPINNING': '탈수 중',
      'IDLE': '대기 중',
      'FINISHED': '완료',
      'OFF': '꺼짐'
    };
    return statusMap[status] || status;
  };

  const getVibrationStatus = (machine) => {
    if (machine.status === 'running') {
      if (machine.current_cycle === 'wash') {
        return '세탁 중 (진동 감지)';
      } else if (machine.current_cycle === 'spin') {
        return '탈수 중 (강한 진동)';
      } else if (machine.current_cycle === 'rinse') {
        return '헹굼 중 (약한 진동)';
      }
    }
    return '진동 없음';
  };

  return (
    <div className={`machine-card ${machine.status}`}>
      <div className="machine-header">
        <div className="machine-number" style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
          {isEditing ? (
            <input
              type="text"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              onBlur={handleSaveName}
              onKeyDown={handleKeyPress}
              disabled={saving}
              autoFocus
              style={{
                fontSize: '1rem',
                padding: '0.25rem 0.5rem',
                border: '2px solid var(--color-primary)',
                borderRadius: '4px',
                width: '100%'
              }}
            />
          ) : (
            <span
              onClick={() => setIsEditing(true)}
              style={{cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.25rem'}}
              title="클릭하여 이름 수정"
            >
              {machine.machine_name || `세탁기 #${machine.machine_number}`}
              <span style={{fontSize: '0.875rem', opacity: 0.6}}>✏️</span>
            </span>
          )}
        </div>
        <span className={`status-badge status-${machine.status}`}>
          {getStatusText(machine.status)}
        </span>
      </div>

      {machine.status === 'running' && (
        <>
          <div className="info-row">
            <span>현재 단계</span>
            <span>{machine.current_cycle === 'wash' ? '세탁' : 
                   machine.current_cycle === 'rinse' ? '헹굼' : '탈수'}</span>
          </div>
          <TimerDisplay machine={machine} />
        </>
      )}

      <div className="machine-info">
        <div className="info-row">
          <span>상태</span>
          <span style={{fontWeight: 500, color: machine.status === 'running' ? 'var(--color-primary)' : 'var(--color-text-secondary)'}}>
            {getVibrationStatus(machine)}
          </span>
        </div>
        <div className="battery-indicator">
          <span>배터리</span>
          <div className="battery-bar">
            <div
              className="battery-fill"
              style={{ width: `${machine.battery}%` }}
            ></div>
          </div>
          <span>{machine.battery}%</span>
        </div>
        {(machine.NewWashThreshold || machine.NewSpinThreshold) && (
          <div className="info-row" style={{fontSize: '0.8rem', color: 'var(--color-text-secondary)'}}>
            <span>적응형 기준점</span>
            <span>
              세탁: {machine.NewWashThreshold?.toFixed(2) || '0.00'} / 
              탈수: {machine.NewSpinThreshold?.toFixed(2) || '0.00'}
            </span>
          </div>
        )}
      </div>

      {machine.status === 'running' && (
        <button
          className={`btn btn-small ${isSubscribed ? 'btn-warning' : 'btn-success'}`}
          onClick={() => {
            if (isSubscribed) {
              onUnsubscribe(machine.id, 'machine');
            } else {
              onSubscribe(machine.id, 'machine', `세탁기 #${machine.machine_number}`);
            }
          }}
        >
          {isSubscribed ? '구독 취소' : '알림 받기'}
        </button>
      )}
    </div>
  );
}

// Machines List Component
function MachinesList({ roomId, rooms, machines, onBack, subscriptions, onSubscribe, onUnsubscribe }) {
  const room = rooms.find(r => r.id === roomId);
  const roomMachines = machines.filter(m => m.room_id === roomId);

  const isSubscribed = (machineId) => {
    return subscriptions.some(sub => sub.type === 'machine' && sub.id === machineId);
  };

  if (!room) return null;

  return (
    <div className="container">
      <a href="#" className="back-button" onClick={(e) => { e.preventDefault(); onBack(); }}>
        ← 뒤로 가기
      </a>
      <div className="page-header">
        <h1>{room.name}</h1>
        <p>{room.location}</p>
        <CongestionBar congestion={room.congestion} />
      </div>
      <div className="machines-grid">
        {roomMachines.map(machine => (
          <MachineCard
            key={machine.id}
            machine={machine}
            onSubscribe={onSubscribe}
            onUnsubscribe={onUnsubscribe}
            isSubscribed={isSubscribed(machine.id)}
          />
        ))}
      </div>
    </div>
  );
}

// Subscriptions Component
function SubscriptionsPage({ subscriptions, onUnsubscribe }) {
  const roomSubs = subscriptions.filter(sub => sub.type === 'room');
  const machineSubs = subscriptions.filter(sub => sub.type === 'machine');

  return (
    <div className="container">
      <div className="page-header">
        <h1>내 구독</h1>
        <p>알림을 받고 있는 세탁실과 세탁기 목록입니다</p>
      </div>
      <div className="subscriptions-container">
        <div className="subscription-section">
          <h3>세탁실 구독</h3>
          {roomSubs.length > 0 ? (
            <div className="subscription-list">
              {roomSubs.map(sub => (
                <div key={sub.id} className="subscription-item">
                  <div className="subscription-info">
                    <h4>{sub.name}</h4>
                    <p>세탁기가 사용 가능해지면 알림을 받습니다</p>
                  </div>
                  <button
                    className="btn btn-small btn-danger"
                    onClick={() => onUnsubscribe(sub.id, 'room')}
                  >
                    구독 취소
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">구독 중인 세탁실이 없습니다</div>
          )}
        </div>

        <div className="subscription-section">
          <h3>세탁기 구독</h3>
          {machineSubs.length > 0 ? (
            <div className="subscription-list">
              {machineSubs.map(sub => (
                <div key={sub.id} className="subscription-item">
                  <div className="subscription-info">
                    <h4>{sub.name}</h4>
                    <p>종료 5분 전과 종료 시 알림을 받습니다</p>
                  </div>
                  <button
                    className="btn btn-small btn-danger"
                    onClick={() => onUnsubscribe(sub.id, 'machine')}
                  >
                    구독 취소
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">구독 중인 세탁기가 없습니다</div>
          )}
        </div>
      </div>
    </div>
  );
}

// Survey Component
function SurveyPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [completed, setCompleted] = useState(false);

  const question = surveyQuestions[currentQuestion];

  const handleAnswer = (answer) => {
    setAnswers({ ...answers, [question.id]: answer });
  };

  const handleNext = () => {
    if (currentQuestion < surveyQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      memoryStorage.surveyAnswers = answers;
      setCompleted(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  if (completed) {
    return (
      <div className="container">
        <div className="survey-container">
          <div className="survey-complete">
            <h2>✓ 설문 완료</h2>
            <p>소중한 의견 감사합니다!</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="survey-container">
        <div className="survey-progress">
          질문 {currentQuestion + 1} / {surveyQuestions.length}
        </div>
        <div className="question-card">
          <h3>{question.question}</h3>
          {question.type === 'rating' && (
            <div className="rating-options">
              {question.options.map(option => (
                <button
                  key={option}
                  className={`rating-btn ${answers[question.id] === option ? 'selected' : ''}`}
                  onClick={() => handleAnswer(option)}
                >
                  {option}
                </button>
              ))}
            </div>
          )}
          {question.type === 'multiple_choice' && (
            <div className="choice-options">
              {question.options.map(option => (
                <button
                  key={option}
                  className={`choice-btn ${answers[question.id] === option ? 'selected' : ''}`}
                  onClick={() => handleAnswer(option)}
                >
                  {option}
                </button>
              ))}
            </div>
          )}
          {question.type === 'text' && (
            <textarea
              className="text-input"
              value={answers[question.id] || ''}
              onChange={(e) => handleAnswer(e.target.value)}
              placeholder="자유롭게 의견을 작성해주세요"
            />
          )}
        </div>
        <div className="survey-actions">
          <button
            className="btn btn-secondary"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
          >
            이전
          </button>
          <button
            className="btn btn-primary"
            onClick={handleNext}
            disabled={!answers[question.id]}
          >
            {currentQuestion < surveyQuestions.length - 1 ? '다음' : '제출'}
          </button>
        </div>
      </div>
    </div>
  );
}

// Settings Component
function SettingsPage() {
  const [serverUrl, setServerUrl] = useState(memoryStorage.serverUrl);
  const [apiMode, setApiMode] = useState('auto');
  const [connectionStatus, setConnectionStatus] = useState('');
  const [testing, setTesting] = useState(false);

  const handleSaveUrl = () => {
    memoryStorage.serverUrl = serverUrl;
    setConnectionStatus('서버 URL이 저장되었습니다');
    setTimeout(() => setConnectionStatus(''), 3000);
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setConnectionStatus('연결 테스트 중...');
    
    try {
      // Test /rooms endpoint
      const response = await fetch(`${serverUrl}/rooms`);
      if (response.ok) {
        setConnectionStatus('✓ 새로운 API 사용 가능 (/rooms)');
      } else if (response.status === 404) {
        setConnectionStatus('⚠ 기존 API만 사용 가능 (/load)');
      } else {
        setConnectionStatus(`✗ 연결 실패: ${response.status}`);
      }
    } catch (error) {
      setConnectionStatus('✗ 서버에 연결할 수 없습니다: ' + error.message);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="container">
      <div className="page-header">
        <h1>설정</h1>
        <p>서버 연결 및 앱 설정을 관리합니다</p>
      </div>
      <div className="survey-container" style={{maxWidth: '600px'}}>
        <div className="form-group">
          <label>서버 URL</label>
          <input
            type="text"
            value={serverUrl}
            onChange={(e) => setServerUrl(e.target.value)}
            placeholder="http://localhost:8000"
            className="form-control"
          />
        </div>
        <div className="card-actions" style={{marginTop: '1rem', display: 'flex', gap: '0.5rem'}}>
          <button className="btn btn-primary" onClick={handleSaveUrl}>
            저장
          </button>
          <button 
            className="btn btn-secondary" 
            onClick={handleTestConnection}
            disabled={testing}
          >
            {testing ? '테스트 중...' : '연결 테스트'}
          </button>
        </div>
        {connectionStatus && (
          <div style={{
            marginTop: '1rem',
            padding: '1rem',
            borderRadius: '8px',
            backgroundColor: connectionStatus.includes('✓') ? '#d1fae5' : 
                           connectionStatus.includes('⚠') ? '#fef3c7' : 
                           connectionStatus.includes('✗') ? '#fee2e2' : '#f3f4f6',
            color: 'var(--color-text)'
          }}>
            {connectionStatus}
          </div>
        )}
        <div style={{marginTop: '2rem', padding: '1rem', backgroundColor: '#f9fafb', borderRadius: '8px'}}>
          <h4 style={{marginBottom: '0.5rem'}}>API 정보</h4>
          <p style={{fontSize: '0.875rem', color: 'var(--color-text-secondary)', marginBottom: '0.5rem'}}>
            앱이 자동으로 사용 가능한 API를 감지합니다:
          </p>
          <ul style={{fontSize: '0.875rem', color: 'var(--color-text-secondary)', paddingLeft: '1.5rem'}}>
            <li><strong>새로운 API:</strong> GET /rooms, GET /machines</li>
            <li><strong>기존 API:</strong> POST /load (구독한 세탁기만)</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

// Main App Component
function App() {
  const [user, setUser] = useState(memoryStorage.user);
  const [currentPage, setCurrentPage] = useState('rooms');
  const [selectedRoomId, setSelectedRoomId] = useState(null);
  const [laundryRooms, setLaundryRooms] = useState([]);
  const [washingMachines, setWashingMachines] = useState([]);
  const [mySubscriptionIds, setMySubscriptionIds] = useState([]);
  const [subscriptions, setSubscriptions] = useState(memoryStorage.subscriptions);
  const [notificationPermission, setNotificationPermission] = useState('default');
  const [wsConnected, setWsConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [apiMode, setApiMode] = useState('unknown');
  const [errorMessage, setErrorMessage] = useState('');
  const [debugLog, setDebugLog] = useState([]);
  const [showDebug, setShowDebug] = useState(true);
  const notificationSentRef = useRef(new Set());
  const wsRef = useRef(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimeoutRef = useRef(null);

  // Request notification permission
  useEffect(() => {
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  const requestNotificationPermission = async () => {
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
    }
  };

  const sendNotification = (title, body) => {
    const notifKey = `${title}-${body}`;
    if (notificationSentRef.current.has(notifKey)) return;
    
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body, icon: '🧺' });
      notificationSentRef.current.add(notifKey);
    }
  };

  // Helper: Group machines by room_id
  const groupMachinesByRoom = (machines) => {
    const roomMap = {};
    
    machines.forEach(machine => {
      const roomId = machine.room_id;
      const roomName = machine.room_name;
      
      if (!roomMap[roomId]) {
        roomMap[roomId] = {
          room_id: roomId,
          room_name: roomName,
          machines: []
        };
      }
      roomMap[roomId].machines.push(machine);
    });
    
    return Object.values(roomMap).map(room => ({
      id: room.room_id,
      name: room.room_name,
      location: room.room_name,
      total_machines: room.machines.length,
      available_machines: room.machines.filter(m => 
        ['IDLE', 'OFF', 'FINISHED'].includes(m.status)
      ).length,
      running_machines: room.machines.filter(m => 
        ['WASHING', 'SPINNING'].includes(m.status)
      ).length,
      congestion: Math.round(
        (room.machines.filter(m => ['WASHING', 'SPINNING'].includes(m.status)).length / 
         room.machines.length) * 100
      )
    }));
  };

  // Helper: Group machines by room_name (no room_id)
  const groupMachinesByRoomName = (machines) => {
    const roomMap = {};
    
    machines.forEach(machine => {
      const roomName = machine.room_name;
      
      if (!roomMap[roomName]) {
        roomMap[roomName] = {
          room_name: roomName,
          machines: []
        };
      }
      roomMap[roomName].machines.push(machine);
    });
    
    return Object.values(roomMap).map(room => ({
      id: room.room_name,
      name: room.room_name,
      location: room.room_name,
      total_machines: room.machines.length,
      available_machines: room.machines.filter(m => 
        ['IDLE', 'OFF', 'FINISHED'].includes(m.status)
      ).length,
      running_machines: room.machines.filter(m => 
        ['WASHING', 'SPINNING'].includes(m.status)
      ).length,
      congestion: Math.round(
        (room.machines.filter(m => ['WASHING', 'SPINNING'].includes(m.status)).length / 
         room.machines.length) * 100
      )
    }));
  };

  // Note: loadAllRooms 제거됨 - loadData가 /load API만 사용

  // Note: /my_subscriptions API 제거됨 - /load API만 사용

  // Note: loadMachinesFromRoom 제거됨 - /load API가 모든 세탁기 데이터 포함

  // Note: loadMachinesFromLegacyAPI 제거됨 - loadData가 모든 기능 처리

  // Add debug log
  const addDebugLog = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString('ko-KR');
    const log = { timestamp, message, type };
    setDebugLog(prev => [...prev, log]);
    console.log(`[${timestamp}] ${message}`);
  };

  // Load all data (only /load API)
  const loadData = async () => {
    setLoading(true);
    setErrorMessage('');
    setDebugLog([]);
    
    addDebugLog('=== 데이터 로드 시작 ===', 'info');
    addDebugLog('서버 URL: ' + getServerUrl(), 'info');
    
    const token = memoryStorage.token;
    if (!token) {
      addDebugLog('✗ 토큰이 없습니다', 'error');
      setErrorMessage('로그인 정보가 없습니다. 다시 로그인해주세요.');
      setLoading(false);
      return;
    }
    
    try {
      addDebugLog('POST /load API 호출 중...', 'info');
      const url = `${getServerUrl()}/load`;
      addDebugLog(`  → URL: ${url}`, 'info');
      
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ access_token: token })
      });
      
      addDebugLog(`응답: ${response.status} ${response.statusText}`, 'info');
      
      if (!response.ok) {
        const text = await response.text();
        throw new Error(`API 호출 실패: ${response.status} - ${text.substring(0, 100)}`);
      }
      
      const data = await response.json();
      const machines = data.machine_list || [];
      
      addDebugLog(`✓ ${machines.length}개 세탁기 발견`, 'success');
      
      if (machines.length === 0) {
        addDebugLog('⚠ 구독한 세탁실이 없습니다', 'warn');
        setLaundryRooms([]);
        setWashingMachines([]);
        setErrorMessage('구독한 세탁실이 없습니다. 먼저 세탁실을 구독해주세요.');
      } else {
        // Group by room_name
        addDebugLog('세탁기를 room_name으로 그룹화 중...', 'info');
        const roomMap = new Map();
        const machineList = [];
        
        machines.forEach((machine, index) => {
          const roomId = machine.room_id || machine.room_name;
          const roomName = machine.room_name || `세탁실 ${roomId}`;
          
          if (!roomMap.has(roomId)) {
            roomMap.set(roomId, {
              id: roomId,
              name: roomName,
              location: roomName,
              total_machines: 0,
              available_machines: 0,
              running_machines: 0,
              congestion: 0
            });
          }
          
          const room = roomMap.get(roomId);
          room.total_machines++;
          
          const isAvailable = machine.status === 'IDLE' || machine.status === 'OFF' || machine.status === 'FINISHED';
          const isRunning = machine.status === 'WASHING' || machine.status === 'SPINNING';
          
          if (isAvailable) room.available_machines++;
          if (isRunning) room.running_machines++;
          
          machineList.push({
            id: machine.machine_id || `machine_${index}`,
            room_id: roomId,
            machine_number: machine.machine_id || index + 1,
            machine_name: machine.machine_name || `세탁기 ${machine.machine_id || index + 1}`,
            status: isAvailable ? 'available' : isRunning ? 'running' : 'broken',
            current_cycle: machine.status === 'WASHING' ? 'wash' : 
                          machine.status === 'SPINNING' ? 'spin' : 'rinse',
            battery: machine.battery || 90,
            vibration_magnitude: isRunning ? 120 : 0,
            estimated_end_time: new Date(Date.now() + 15 * 60000).toISOString(),
            user_input_time: 20,
            stat_time: 18
          });
        });
        
        // Calculate congestion
        roomMap.forEach(room => {
          room.congestion = room.total_machines > 0 ? 
            Math.round((room.running_machines / room.total_machines) * 100) : 0;
        });
        
        const rooms = Array.from(roomMap.values());
        addDebugLog(`✓ ${rooms.length}개 세탁실로 그룹화`, 'success');
        
        rooms.forEach(room => {
          addDebugLog(`  - ${room.name}: 전체 ${room.total_machines}대, 사용가능 ${room.available_machines}대, 혼잡도 ${room.congestion}%`, 'info');
        });
        
        setLaundryRooms(rooms);
        setWashingMachines(machineList);
        setMySubscriptionIds(rooms.map(r => r.id));
        setErrorMessage('');
        addDebugLog('✓ 데이터 로드 완료', 'success');
      }
    } catch (error) {
      const errorMsg = `에러: ${error.message}`;
      addDebugLog('✗ ' + errorMsg, 'error');
      setErrorMessage(`세탁실 로드 실패: ${error.message}`);
      setLaundryRooms([]);
      setWashingMachines([]);
    } finally {
      setLoading(false);
      addDebugLog('=== 데이터 로드 완료 ===', 'info');
    }
  };

  // Toggle subscribe/unsubscribe
  const handleToggleSubscribe = async (roomId) => {
    const userSnum = memoryStorage.user?.snum;
    if (!userSnum) {
      alert('사용자 정보가 없습니다');
      return;
    }

    const isSubscribed = mySubscriptionIds.includes(roomId);
    
    try {
      if (isSubscribed) {
        // Unsubscribe
        addDebugLog(`구독 취소 시도: room_id=${roomId}`, 'info');
        const response = await fetch(`${getServerUrl()}/device_unsubscribe?room_id=${roomId}&user_snum=${userSnum}`, {
          method: 'DELETE'
        });
        
        if (response.ok) {
          setMySubscriptionIds(prev => prev.filter(id => id !== roomId));
          addDebugLog('✓ 구독이 취소되었습니다', 'success');
          alert('구독이 취소되었습니다');
          await loadData();
        } else {
          addDebugLog('✗ 구독 취소 실패', 'error');
          alert('구독 취소 실패');
        }
      } else {
        // Subscribe
        addDebugLog(`구독 시도: room_id=${roomId}`, 'info');
        const response = await fetch(`${getServerUrl()}/device_subscribe?room_id=${roomId}&user_snum=${userSnum}`);
        
        if (response.ok) {
          setMySubscriptionIds(prev => [...prev, roomId]);
          addDebugLog('✓ 구독이 완료되었습니다', 'success');
          alert('구독이 완료되었습니다! 세탁실 데이터를 다시 불러옵니다.');
          await loadData();
        } else {
          addDebugLog('✗ 구독 실패', 'error');
          alert('구독 실패');
        }
      }
    } catch (error) {
      addDebugLog('✗ 오류 발생: ' + error.message, 'error');
      alert('오류가 발생했습니다: ' + error.message);
    }
  };

  // WebSocket connection
  const connectWebSocket = () => {
    if (!memoryStorage.token) return;
    
    const wsUrl = getServerUrl().replace('http', 'ws') + `/status_update?token=${memoryStorage.token}`;
    
    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;
      
      ws.onopen = () => {
        console.log('WebSocket connected');
        setWsConnected(true);
        reconnectAttemptsRef.current = 0;
      };
      
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('WebSocket message:', data);
          
          // Update machine status
          if (data.machine_id !== undefined) {
            setWashingMachines(prevMachines => {
              return prevMachines.map(machine => {
                if (machine.id === data.machine_id || machine.machine_number === data.machine_id) {
                  const newStatus = data.status === 'IDLE' ? 'available' : 
                                   data.status === 'FINISHED' ? 'available' :
                                   data.status === 'WASHING' || data.status === 'SPINNING' ? 'running' : machine.status;
                  
                  const newMachine = {
                    ...machine,
                    status: newStatus,
                    battery: data.battery !== undefined ? data.battery : machine.battery,
                    current_cycle: data.status === 'WASHING' ? 'wash' : 
                                  data.status === 'SPINNING' ? 'spin' : machine.current_cycle,
                    vibration_magnitude: data.status === 'WASHING' || data.status === 'SPINNING' ? 120 : 0
                  };
                  
                  // Send notification if subscribed
                  const isSubscribed = subscriptions.some(
                    sub => sub.type === 'machine' && (sub.id === machine.id || sub.id === machine.machine_number)
                  );
                  
                  if (isSubscribed && data.status === 'FINISHED') {
                    sendNotification('세탁 완료', `${machine.machine_name || machine.machine_number + '번'} 세탁기 사용이 완료되었습니다`);
                  }
                  
                  return newMachine;
                }
                return machine;
              });
            });
            
            // Update room congestion
            setLaundryRooms(prevRooms => {
              return prevRooms.map(room => {
                const roomMachines = washingMachines.filter(m => m.room_id === room.id);
                const available = roomMachines.filter(m => m.status === 'available').length;
                const congestion = Math.floor((1 - available / room.total_machines) * 100);
                return { ...room, congestion, available_machines: available };
              });
            });
          }
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };
      
      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setWsConnected(false);
      };
      
      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setWsConnected(false);
        
        // Reconnect logic
        if (reconnectAttemptsRef.current < 5) {
          reconnectAttemptsRef.current++;
          reconnectTimeoutRef.current = setTimeout(() => {
            console.log(`Reconnecting... attempt ${reconnectAttemptsRef.current}`);
            connectWebSocket();
          }, 3000);
        }
      };
    } catch (error) {
      console.error('Failed to connect WebSocket:', error);
      setWsConnected(false);
    }
  };

  // Load data and connect WebSocket on login
  useEffect(() => {
    if (!user) return;
    
    loadData();
    connectWebSocket();
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [user]);

  // Simulate real-time updates for demo purposes
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(() => {
      setWashingMachines(prevMachines => {
        return prevMachines.map(machine => {
          if (machine.status === 'running') {
            const endTime = new Date(machine.estimated_end_time).getTime();
            const now = Date.now();
            const timeLeft = Math.floor((endTime - now) / 1000);

            // Check for notifications
            const isSubscribed = subscriptions.some(
              sub => sub.type === 'machine' && sub.id === machine.id
            );

            if (isSubscribed) {
              // 5 minutes before end
              if (timeLeft > 0 && timeLeft <= 300 && timeLeft > 295) {
                sendNotification(
                  '세탁 종료 예정',
                  `${machine.machine_number}번 세탁기가 5분 후 종료됩니다`
                );
              }
              // Machine finished
              if (timeLeft <= 0) {
                sendNotification(
                  '세탁 완료',
                  `${machine.machine_number}번 세탁기 사용이 완료되었습니다`
                );
              }
            }

            // Finish machine
            if (timeLeft <= 0) {
              return { ...machine, status: 'available', vibration_magnitude: 0 };
            }

            // Update vibration based on cycle
            const newVibration = machine.current_cycle === 'spin' 
              ? 140 + Math.random() * 40
              : machine.current_cycle === 'wash'
              ? 100 + Math.random() * 30
              : 80 + Math.random() * 30;

            return {
              ...machine,
              vibration_magnitude: Math.floor(newVibration),
              battery: Math.max(50, machine.battery - 0.1)
            };
          }
          return machine;
        });
      });

      // Update room congestion
      setLaundryRooms(prevRooms => {
        return prevRooms.map(room => {
          const roomMachines = washingMachines.filter(m => m.room_id === room.id);
          const available = roomMachines.filter(m => m.status === 'available').length;
          const congestion = Math.floor((1 - available / room.total_machines) * 100);

          // Check for room subscription notifications
          const wasUnavailable = room.available_machines === 0;
          const nowAvailable = available > 0;
          const isSubscribed = subscriptions.some(
            sub => sub.type === 'room' && sub.id === room.id
          );

          if (isSubscribed && wasUnavailable && nowAvailable) {
            sendNotification(
              '세탁기 사용 가능',
              `${room.name}에 세탁기가 사용 가능합니다`
            );
          }

          return {
            ...room,
            congestion,
            available_machines: available
          };
        });
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [user, subscriptions, washingMachines]);

  const handleLogin = (userData) => {
    setUser(userData);
    memoryStorage.user = userData;
  };

  const handleLogout = async () => {
    try {
      if (memoryStorage.token) {
        await apiCall('/logout', {
          method: 'POST',
          body: JSON.stringify({ access_token: memoryStorage.token })
        });
      }
    } catch (error) {
      console.error('Logout failed:', error);
    } finally {
      setUser(null);
      memoryStorage.user = null;
      memoryStorage.token = null;
      setCurrentPage('rooms');
      setSelectedRoomId(null);
      if (wsRef.current) {
        wsRef.current.close();
      }
    }
  };

  const handleSubscribe = async (id, type, name) => {
    if (notificationPermission !== 'granted') {
      requestNotificationPermission();
    }

    try {
      if (type === 'room') {
        // Subscribe to room
        await apiCall(`/device_subscribe?room_id=${id}&user_snum=${user.snum}`, {
          method: 'GET'
        });
      } else if (type === 'machine') {
        // Subscribe to machine
        await apiCall('/notify_me', {
          method: 'POST',
          body: JSON.stringify({
            access_token: memoryStorage.token,
            machine_id: id,
            isusing: 1
          })
        });
      }
      
      const newSub = { id, type, name, timestamp: Date.now() };
      const newSubscriptions = [...subscriptions, newSub];
      setSubscriptions(newSubscriptions);
      memoryStorage.subscriptions = newSubscriptions;

      sendNotification('구독 완료', `${name} 알림 구독이 완료되었습니다`);
    } catch (error) {
      console.error('Subscribe failed:', error);
      alert('구독 실패: ' + error.message);
    }
  };

  const handleUnsubscribe = async (id, type) => {
    try {
      if (type === 'machine') {
        await apiCall('/notify_me', {
          method: 'POST',
          body: JSON.stringify({
            access_token: memoryStorage.token,
            machine_id: id,
            isusing: 0
          })
        });
      }
      
      const newSubscriptions = subscriptions.filter(
        sub => !(sub.id === id && sub.type === type)
      );
      setSubscriptions(newSubscriptions);
      memoryStorage.subscriptions = newSubscriptions;
    } catch (error) {
      console.error('Unsubscribe failed:', error);
      alert('구독 취소 실패: ' + error.message);
    }
  };

  const handleSelectRoom = async (roomId) => {
    setSelectedRoomId(roomId);
    setCurrentPage('machines');
  };

  const handleBack = () => {
    setSelectedRoomId(null);
    setCurrentPage('rooms');
  };

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="app">
      <Navbar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onLogout={handleLogout}
        wsConnected={wsConnected}
      />
      <div className="container">
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem'}}>
          <div style={{fontSize: '0.875rem', color: 'var(--color-text-secondary)'}}>
            서버: {memoryStorage.serverUrl} | API: {apiMode === 'new' ? '새로운' : apiMode === 'legacy' ? '기존' : '감지 중'}
          </div>
          <div style={{display: 'flex', alignItems: 'center', gap: '1rem'}}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: wsConnected ? 'var(--color-success)' : 'var(--color-danger)'
            }}></div>
            <span style={{fontSize: '0.875rem', color: 'var(--color-text-secondary)'}}>
              {wsConnected ? '연결됨' : '연결 끊김'}
            </span>
          </div>
        </div>
      </div>
      {notificationPermission === 'default' && (
        <div className="container">
          <div className="notification-banner">
            <p>알림을 받으려면 권한을 허용해주세요</p>
            <button
              className="btn btn-small btn-warning"
              onClick={requestNotificationPermission}
            >
              알림 허용
            </button>
          </div>
        </div>
      )}
      {loading && (
        <div className="loading">데이터를 불러오는 중...</div>
      )}
      {currentPage === 'rooms' && (
        <AllRoomsList
          rooms={laundryRooms}
          onSelectRoom={handleSelectRoom}
          mySubscriptions={mySubscriptionIds}
          onToggleSubscribe={handleToggleSubscribe}
          errorMessage={errorMessage}
          onRefresh={loadData}
          loading={loading}
          debugLog={debugLog}
          showDebug={showDebug}
          onToggleDebug={() => setShowDebug(!showDebug)}
        />
      )}
      {currentPage === 'machines' && selectedRoomId && (
        <MachinesList
          roomId={selectedRoomId}
          rooms={laundryRooms}
          machines={washingMachines}
          onBack={handleBack}
          subscriptions={subscriptions}
          onSubscribe={handleSubscribe}
          onUnsubscribe={handleUnsubscribe}
        />
      )}
      {currentPage === 'subscriptions' && (
        <MySubscriptionsPage
          allRooms={laundryRooms}
          mySubscriptions={mySubscriptionIds}
          onSelectRoom={handleSelectRoom}
          onToggleSubscribe={handleToggleSubscribe}
          onNavigateToAllRooms={() => setCurrentPage('rooms')}
        />
      )}

    </div>
  );
}

// Render the app
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);