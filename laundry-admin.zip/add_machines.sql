-- 세탁기 추가 SQL

-- 현재 데이터베이스 상태:
-- room_id=1: 수원a기숙사 (세탁기 0개)
-- room_id=2: 수원(a) (세탁기 4개) ✅
-- room_id=3: 1234 (세탁기 0개)

-- ===== 수원a기숙사에 세탁기 추가 =====
INSERT INTO machine_table 
(machine_id, machine_name, room_id, room_name, status, battery, battery_capacity, last_update, timestamp, NewWashThreshold, NewSpinThreshold)
VALUES 
(5, '수원a-1번', 1, '수원a기숙사', 'IDLE', 100, 100, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), 0.0, 0.0),
(6, '수원a-2번', 1, '수원a기숙사', 'IDLE', 95, 100, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), 0.0, 0.0);

-- ===== 1234에 세탁기 추가 =====
INSERT INTO machine_table 
(machine_id, machine_name, room_id, room_name, status, battery, battery_capacity, last_update, timestamp, NewWashThreshold, NewSpinThreshold)
VALUES 
(7, '1234-1번', 3, '1234', 'IDLE', 100, 100, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), 0.0, 0.0),
(8, '1234-2번', 3, '1234', 'IDLE', 90, 100, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), 0.0, 0.0);

-- ===== 확인 쿼리 =====
SELECT room_id, room_name, COUNT(*) as machine_count
FROM machine_table
GROUP BY room_id, room_name
ORDER BY room_id;

-- 예상 결과:
-- room_id | room_name    | machine_count
-- --------|--------------|---------------
-- 1       | 수원a기숙사  | 2
-- 2       | 수원(a)      | 4
-- 3       | 1234         | 2

-- ===== 모든 세탁기 확인 =====
SELECT machine_id, machine_name, room_name, status, battery
FROM machine_table
ORDER BY room_id, machine_id;
